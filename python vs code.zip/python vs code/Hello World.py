# Name: Shamal Nayak
# Question: Python Program to Print Hello World

print("Hello World!")