# Name: Shamal Nayak
# Question: Python Program to Print the Fibonacci Sequence

n = int(input("Enter number of terms: "))

a = 0
b = 1

print("Fibonacci Sequence:")

for i in range(n):
    print(a)
    c = a + b
    a = b
    b = c