# Name: Shamal Nayak
# Question: Python Program to Count the Number of Each Vowel

text = input("Enter a string: ").lower()

vowels = "aeiou"
count = {}

for v in vowels:
    count[v] = 0

for char in text:
    if char in vowels:
        count[char] += 1

print("Vowel count:")
for v in vowels:
    print(v, ":", count[v])