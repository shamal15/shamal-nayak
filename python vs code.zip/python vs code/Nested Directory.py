# Name: Shamal Nayak
# Question: Python Program to Safely Create a Nested Directory

import os
path = "folder1/folder2/folder3"
os.makedirs(path, exist_ok=True)
print("Nested directory created successfully")