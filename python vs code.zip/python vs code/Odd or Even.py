# Name: Shamal Nayak
# Question: Python Program to Check if a Number is Odd or Even

num = int(input("Enter a number: "))

if num % 2 == 0:
    print("The number is Even")
else:
    print("The number is Odd")