# Name: Shamal Nayak
# Question: Python Program to Check if a Number is Positive, Negative or Zero

num = float(input("Enter a number: "))

if num > 0:
    print("Positive Number")
elif num < 0:
    print("Negative Number")
else:
    print("Number is Zero")