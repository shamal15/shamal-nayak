# Name: Shamal Nayak
# Question: Python Program to Access Index of a List Using for Loop

numbers = [10, 20, 30, 40, 50]

for i in range(len(numbers)):
    print("Index:", i, "Value:", numbers[i])