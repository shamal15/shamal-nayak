# Question: Write a Python program to display Fibonacci sequence using recursion | Name: Shamal Nayak
def fib(n):
    if n<=1:
        return n
    return fib(n-1)+fib(n-2)

n=int(input("Enter number:"))
for i in range(n):
    print(fib(i),end=" ")