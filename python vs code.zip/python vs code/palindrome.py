# Question: Write a Python program to check whether a string is palindrome or not | Name: Shamal Nayak
s=input("Enter string: ")

if s==s[::-1]:
    print("Palindrome")
else:
    print("Not Palindrome")