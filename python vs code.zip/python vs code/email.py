# Name: Shamal Nayak
# Question: Python Program to Merge Emails

list1 = ["vijuu1504@gmail.com", "kram1504@gmail.com"]
list2 = ["kritu1504@gmail.com", "kvikudii1504@gmail.com"]

merged = list1 + list2

print("Merged Email List:")
for email in merged:
    print(email)