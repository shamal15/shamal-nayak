# Name: Shamal Nayak
# Question: Python Program to Add Two Numbers

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

sum = a + b

print("Sum =", sum)