# Question: Write a Python program to display calendar | Name: Shamal Nayak
import calendar
y=int(input("Enter year: "))
m=int(input("Enter month: "))
print(calendar.month(y,m))
