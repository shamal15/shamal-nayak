# Question: Write a Python program to remove punctuations from a string | Name: Shamal Nayak
p='''!()-[]{};:'"\,<>./?@#$%^&*_~'''

s=input("Enter string: ")
r=""

for i in s:
    if i not in p:
        r=r+i

print(r)