# Question: Write a Python program to multiply two matrices | Name: Shamal Nayak
r1=int(input("Rows of A: "))
c1=int(input("Columns of A: "))

A=[]
for i in range(r1):
    A.append(list(map(int,input().split())))

r2=int(input("Rows of B: "))
c2=int(input("Columns of B: "))

B=[]
for i in range(r2):
    B.append(list(map(int,input().split())))

R=[[0]*c2 for i in range(r1)]

for i in range(r1):
    for j in range(c2):
        for k in range(c1):
            R[i][j]+=A[i][k]*B[k][j]

for i in R:
    print(*i)