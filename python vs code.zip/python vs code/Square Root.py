# Name: Shamal Nayak
# Question: Python Program to Find the Square Root

import math

num = float(input("Enter a number: "))

result = math.sqrt(num)

print("Square root =", result)