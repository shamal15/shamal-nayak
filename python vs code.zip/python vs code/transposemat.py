# Question: Write a Python program to transpose a matrix | Name: Shamal Nayak
r=int(input("Rows: "))
c=int(input("Columns: "))

A=[]
for i in range(r):
    A.append(list(map(int,input().split())))

for i in range(c):
    for j in range(r):
        print(A[j][i],end=" ")
    print()