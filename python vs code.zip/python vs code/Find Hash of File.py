# Name: Shamal Nayak
# Question: Python Program to Find Hash of File

import hashlib

# file path
path = r"C:\Users\SHAMAL\Downloads\python vs code\sample.txt"

# create file if it does not exist
with open(path, "w") as f:
    f.write("Hello this is a sample file")

# open file in binary mode
with open(path, "rb") as file:
    data = file.read()

# generate hash
hash_value = hashlib.md5(data).hexdigest()

print("File Hash:", hash_value)