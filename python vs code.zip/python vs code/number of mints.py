# Name: Shamal Nayak
# Problem: Minting Mints

n = int(input("Enter mints of first kid: "))
length = int(input("Enter number of kids in queue: "))

total = 0

for i in range(length):
    total = total + (n - i)

print("Total mints:", total)
