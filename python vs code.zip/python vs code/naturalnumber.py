# Question: Write a Python program to find sum of natural numbers using recursion | Name: Shamal Nayak
def sum(n):
    if n==0:
        return 0
    return n+sum(n-1)

n=int(input("Enter number: "))
print(sum(n))