# Name: Shamal Nayak
# Question: Python Program to Calculate the Area of a Triangle

base = float(input("Enter base: "))
height = float(input("Enter height: "))

area = 0.5 * base * height

print("Area of triangle =", area)