# Name: Shamal Nayak
# Question: Python Program to Find the Size (Resolution) of an Image

from PIL import Image

img = Image.open("C:/Users/SHAMAL/Downloads/python vs code/photo.jpg.jpeg")

width, height = img.size

print("Image Width:", width)
print("Image Height:", height)