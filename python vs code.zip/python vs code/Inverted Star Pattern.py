# Python Program to Print Inverted Star Pattern
# Name: shamal nayak

n = 5

for i in range(n, 0, -1):
    for j in range(i):
        print("*", end=" ")
    print()