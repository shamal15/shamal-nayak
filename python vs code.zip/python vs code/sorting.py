# Name: Shamal Nayak
# Question: Python Program to Sort Words in Alphabetic Order

text = input("Enter a sentence: ")

words = text.split()
words.sort()

print("Words in alphabetical order:")
for word in words:
    print(word)