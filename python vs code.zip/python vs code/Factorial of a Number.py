# Name: Shamal Nayak
# Question: Python Program to Find the Factorial of a Number

num = int(input("Enter a number: "))

fact = 1

for i in range(1, num + 1):
    fact = fact * i

print("Factorial:", fact)