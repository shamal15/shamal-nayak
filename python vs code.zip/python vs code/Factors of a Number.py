# Python Program to Find the Factors of a Number
# Name: shamal nayak

num = int(input("Enter number: "))

for i in range(1, num+1):
    if num % i == 0:
        print(i, end=" ")