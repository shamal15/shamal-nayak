# Python Program to Convert Decimal to Binary, Octal and Hexadecimal
# Name: shamal nayak

num = int(input("Enter number: "))

print("Binary:", bin(num))
print("Octal:", oct(num))
print("Hexadecimal:", hex(num))