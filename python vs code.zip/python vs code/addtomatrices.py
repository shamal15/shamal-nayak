# Question: Write a Python program to add two matrices | Name: Shamal Nayak
r=int(input("Rows: "))
c=int(input("Columns: "))

A=[]
B=[]

print("Enter matrix A")
for i in range(r):
    A.append(list(map(int,input().split())))

print("Enter matrix B")
for i in range(r):
    B.append(list(map(int,input().split())))

for i in range(r):
    for j in range(c):
        print(A[i][j]+B[i][j],end=" ")
    print()