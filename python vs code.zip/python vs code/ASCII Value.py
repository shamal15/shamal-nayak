# Python Program to Find ASCII Value of Character
# Name: shamal nayak

ch = input("Enter character: ")

print("ASCII value:", ord(ch))