# Python Program to Find HCF or GCD
# Name: shamal nayak

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

while b != 0:
    a, b = b, a % b

print("GCD:", a)