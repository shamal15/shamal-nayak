# Question: Write a Python program to convert decimal to binary using recursion | Name: Shamal Nayak
def binary(n):
    if n>1:
        binary(n//2)
    print(n%2,end="")

n=int(input("Enter decimal number: "))
binary(n)