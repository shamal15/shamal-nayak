class A:
    def demo(self):
        print("hello A")
class B(A):
    def demo(self):
        print ("hello B")
        super().__demo()
class c(B):
    def demo(self):
        super().__demo()
        print("hello c")
                    
obj=B()
obj.demo()