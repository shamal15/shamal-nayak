# Name: Shamal Nayak
# Question: Python Program to Generate a Random Number

import random

num = random.randint(1, 100)

print("Random number:", num)