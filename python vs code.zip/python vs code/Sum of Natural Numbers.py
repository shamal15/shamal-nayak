# Python Program to Find the Sum of Natural Numbers
# Name: shamal nayak

n = int(input("Enter number: "))
sum = 0

for i in range(1, n+1):
    sum += i

print("Sum =", sum)