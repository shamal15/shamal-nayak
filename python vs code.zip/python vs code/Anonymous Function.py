# Python Program to Display Powers of 2 Using Anonymous Function
# Name: shamal nayak

terms = int(input("Enter terms: "))

result = list(map(lambda x: 2**x, range(terms)))

print(result)