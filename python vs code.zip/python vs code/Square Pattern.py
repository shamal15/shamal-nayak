# Python Program to Print Square Pattern with Middle Hole
# Name: shamal nayak

n = 8

for i in range(n):
    for j in range(n):
        if i == 0 or i == n-1 or j == 0 or j == n-1:
            print("*", end="")
        else:
            print(" ", end="")
    print()