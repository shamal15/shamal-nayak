# Python Program to Shuffle Deck of Cards
# Name: shamal nayak

import random
import itertools

deck = list(itertools.product(range(1,14), ['Spade','Heart','Diamond','Club']))

random.shuffle(deck)

for i in range(5):
    print(deck[i])