# Python Program to Find Numbers Divisible by Another Number
# Name: shamal nayak

list1 = list(map(int, input("Enter numbers: ").split()))
n = int(input("Enter divisor: "))

result = list(filter(lambda x: x % n == 0, list1))

print(result)